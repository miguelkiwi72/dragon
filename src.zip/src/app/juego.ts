export interface Juego {
}
