export interface Mesa {
    id_mesa: number;
    tipomesa: number;
    disponible:boolean;

}
