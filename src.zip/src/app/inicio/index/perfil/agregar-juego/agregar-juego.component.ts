import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-agregar-juego',
  standalone: true,
  imports: [RouterLink,RouterOutlet],
  templateUrl: './agregar-juego.component.html',
  styleUrl: './agregar-juego.component.css'
})
export class AgregarJuegoComponent {




}
